import type { AbsoluteViewProps } from '../../types/types';
import React from 'react';
export declare const AbsoluteBox: React.FC<AbsoluteViewProps>;
//# sourceMappingURL=index.d.ts.map