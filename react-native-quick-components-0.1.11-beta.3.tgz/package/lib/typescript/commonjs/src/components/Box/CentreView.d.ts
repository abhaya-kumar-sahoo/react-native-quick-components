import type { BoxProps } from '../../types/types';
import React from 'react';
export declare const CentreView: React.FC<BoxProps>;
//# sourceMappingURL=CentreView.d.ts.map