import React from 'react';
type IconProps = {
    size?: number;
    color?: string;
    children?: React.ReactNode;
    strokeWidth?: number;
};
export declare const EyeIcon: React.FC<IconProps>;
export declare const EyeClosedIcon: React.FC<IconProps>;
export declare const CloseIcon: React.FC<IconProps>;
export declare const EmailIcon: React.FC<IconProps>;
export declare const PhoneIcon: React.FC<IconProps>;
export declare const PasswordIcon: React.FC<IconProps>;
export {};
//# sourceMappingURL=icons.d.ts.map