import type { FlexViewProps } from '../../types/types';
import React from 'react';
export declare const FlexView: React.FC<FlexViewProps>;
//# sourceMappingURL=flex.index.d.ts.map