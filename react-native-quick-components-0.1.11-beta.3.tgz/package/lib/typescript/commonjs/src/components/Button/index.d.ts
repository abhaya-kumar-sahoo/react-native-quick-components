import type { AppButtonProps } from '../../types/types';
import React from 'react';
export declare const AppButton: React.FC<AppButtonProps>;
//# sourceMappingURL=index.d.ts.map