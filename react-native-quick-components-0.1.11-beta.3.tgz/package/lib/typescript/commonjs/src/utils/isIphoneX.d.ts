export declare function isIphoneX(): boolean;
export declare function ifIphoneX(iphoneXStyle: any, regularStyle: any): any;
export declare function getStatusBarHeight(safe: boolean): any;
export declare function getBottomSpace(): 34 | 0;
//# sourceMappingURL=isIphoneX.d.ts.map