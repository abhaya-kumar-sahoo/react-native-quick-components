import type { CustomViewProps } from '../../types/types';
import React from 'react';
export declare const AppView: React.FC<CustomViewProps>;
//# sourceMappingURL=index.d.ts.map