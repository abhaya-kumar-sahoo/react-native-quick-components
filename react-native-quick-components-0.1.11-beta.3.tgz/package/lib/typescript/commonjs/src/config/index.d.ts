interface NewConfig {
    defaultTextColor?: string;
    defaultBackgroundColor?: string | null;
    defaultFontFamily?: string | null;
    defaultFontSize?: number;
    enableResponsive?: boolean;
    responsive?: {
        enabled?: boolean;
        type: 'responsive-h-w' | 'percentage';
        defaultScreenSize?: {
            width?: number;
            height?: number;
        };
    };
}
export declare let config: NewConfig;
export declare const defaultConfig: (newConfig: NewConfig) => void;
export {};
//# sourceMappingURL=index.d.ts.map