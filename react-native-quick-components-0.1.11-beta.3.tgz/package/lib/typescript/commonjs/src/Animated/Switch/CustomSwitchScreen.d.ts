export declare const CustomSwitchScreen: () => import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=CustomSwitchScreen.d.ts.map