import type { CustomCircleProps } from '../../types/types';
import React from 'react';
export declare const CircleView: React.FC<CustomCircleProps>;
//# sourceMappingURL=index.d.ts.map