import type { FlexViewProps } from '../../types/types';
import React from 'react';
export declare const FlexSafeView: React.FC<FlexViewProps>;
//# sourceMappingURL=flex.safearea.index.d.ts.map