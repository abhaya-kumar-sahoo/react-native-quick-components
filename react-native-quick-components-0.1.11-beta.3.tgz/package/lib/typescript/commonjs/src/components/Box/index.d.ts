import type { BoxProps } from '../../types/types';
import React from 'react';
export declare const BoxView: React.FC<BoxProps>;
//# sourceMappingURL=index.d.ts.map