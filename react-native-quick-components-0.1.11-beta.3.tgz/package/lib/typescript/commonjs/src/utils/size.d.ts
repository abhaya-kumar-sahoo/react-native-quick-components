export declare const scale: (size: number) => number;
export declare const verticalScale: (size: number) => number;
export declare const moderateScale: (size: number, factor?: number) => number;
export declare const moderateVerticalScale: (size: number, factor?: number) => number;
//# sourceMappingURL=size.d.ts.map