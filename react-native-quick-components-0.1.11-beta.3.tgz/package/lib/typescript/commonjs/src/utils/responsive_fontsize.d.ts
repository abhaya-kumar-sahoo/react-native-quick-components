export declare function fontSizePct(percent: number): number;
export declare function fontSizeScreenHeight(fontSize: number, standardScreenHeight?: number): number;
/**
 * Calculate responsive width based on percentage of screen width
 * @param percent - Percentage of screen width (0-100)
 * @returns Calculated width in pixels
 */
export declare function widthPct(percent: number): number;
/**
 * Calculate responsive height based on percentage of adjusted screen height
 * @param percent - Percentage of screen height (0-100)
 * @returns Calculated height in pixels
 */
export declare function heightPct(percent: number): number;
/**
 * Calculate responsive width based on reference screen width
 * @param size - Size in pixels on reference device
 * @param standardScreenWidth - Reference screen width (default: 375)
 * @returns Calculated width in pixels
 */
export declare function responsiveWidth(size: number, standardScreenWidth?: number): number;
/**
 * Calculate responsive height based on reference screen height
 * @param size - Size in pixels on reference device
 * @param standardScreenHeight - Reference screen height (default: 680)
 * @returns Calculated height in pixels
 */
export declare function responsiveHeight(size: number, standardScreenHeight?: number): number;
//# sourceMappingURL=responsive_fontsize.d.ts.map