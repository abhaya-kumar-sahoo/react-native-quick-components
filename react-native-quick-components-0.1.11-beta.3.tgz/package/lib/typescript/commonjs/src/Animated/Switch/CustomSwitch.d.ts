import { type SwitchProps } from 'react-native';
type SwitchProp = {
    activeColor?: string;
    inActiveColor?: string;
    onValueChange?: (res: boolean) => void;
    value?: boolean;
    width?: number;
    height?: number;
    activeThumbColor?: string;
    inActiveThumbColor?: string;
} & SwitchProps;
export declare const AppSwitch: ({ activeColor, inActiveColor, activeThumbColor, inActiveThumbColor, onValueChange, value, width, height, }: SwitchProp) => import("react/jsx-runtime").JSX.Element;
export {};
//# sourceMappingURL=CustomSwitch.d.ts.map