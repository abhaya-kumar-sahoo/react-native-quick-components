import type { CustomImageProps } from '../../types/types';
import React from 'react';
export declare const AppImage: React.FC<CustomImageProps>;
//# sourceMappingURL=index.d.ts.map