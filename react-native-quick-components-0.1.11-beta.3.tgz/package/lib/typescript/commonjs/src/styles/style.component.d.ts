import type { ViewStyle } from 'react-native';
import { type FontSizeTypes } from '../types/text.types';
declare const commonPadMadStyles: (value?: any) => {
    padding: any;
    paddingLeft: any;
    paddingRight: any;
    paddingTop: any;
    paddingBottom: any;
    paddingHorizontal: any;
    paddingVertical: any;
    margin: any;
    marginLeft: any;
    marginRight: any;
    marginTop: any;
    marginBottom: any;
    marginHorizontal: any;
    marginVertical: any;
};
declare const commonBackGroundColor: (value?: any, enabled?: boolean) => {
    backgroundColor?: any;
};
declare const commonBorderColor: (value?: any) => {
    borderColor?: any;
};
declare const commonTextColor: (value?: any) => {
    color?: any;
};
declare const commonShadowStyles: (value?: any) => {
    elevation?: any;
    shadowRadius?: any;
    shadowOpacity?: any;
    shadowOffset?: {
        width: any;
        height: any;
    } | undefined;
    shadowColor?: any;
};
declare const commonJcAlineFlexStyle: (value?: any) => {
    alignItems: any;
    justifyContent: string;
    flex?: any;
};
declare const commonFlexStyles: (value?: any) => {
    flexWrap?: any;
    flexShrink?: any;
    flexGrow?: any;
    flexBasis?: any;
};
declare const commonAlignSelf: (value?: any, isEnabled?: boolean) => {
    alignSelf: any;
};
declare const commonColor: (value?: any, enabled?: boolean) => {
    backgroundColor?: any;
};
declare const commonBorder: (value?: any) => {
    borderColor?: any;
    borderRadius: any;
    borderWidth: any;
    borderTopLeftRadius: any;
    borderTopRightRadius: any;
    borderBottomLeftRadius: any;
    borderBottomRightRadius: any;
};
declare const commonSizes: (value?: any, isOverflow?: boolean) => {
    overflow?: any;
    width: any;
    height: any;
    minWidth: any;
    minHeight: any;
    maxWidth: any;
    maxHeight: any;
    aspectRatio: any;
};
export declare function getFontSize(fontSize: FontSizeTypes): number;
declare const commonTextStyles: (value?: any) => {
    overflow?: any;
    width: any;
    height: any;
    minWidth: any;
    minHeight: any;
    maxWidth: any;
    maxHeight: any;
    aspectRatio: any;
    padding: any;
    paddingLeft: any;
    paddingRight: any;
    paddingTop: any;
    paddingBottom: any;
    paddingHorizontal: any;
    paddingVertical: any;
    margin: any;
    marginLeft: any;
    marginRight: any;
    marginTop: any;
    marginBottom: any;
    marginHorizontal: any;
    marginVertical: any;
    color?: any;
    lineHeight?: any;
    textAlign?: any;
    fontFamily?: any;
    fontWeight?: any;
    fontSize?: number | undefined;
};
declare const commonWidthHeight: (value?: any) => {
    width?: any;
    height?: any;
};
declare const center: (value?: any) => {
    alignItems: ViewStyle["alignItems"];
    justifyContent: ViewStyle["justifyContent"];
} | {
    alignItems?: undefined;
    justifyContent?: undefined;
};
declare const centerX: (value?: any) => {
    alignItems: ViewStyle["alignItems"];
} | {
    alignItems?: undefined;
};
declare const centerY: (value?: any) => {
    justifyContent: ViewStyle["justifyContent"];
} | {
    justifyContent?: undefined;
};
declare const commonGapStyles: (value?: any) => {
    columnGap?: any;
    rowGap?: any;
    gap?: any;
    flexWrap: any;
};
declare const commonFlexStyle: (value?: any) => {
    flex?: any;
};
export { commonBackGroundColor, commonWidthHeight, commonPadMadStyles, commonTextStyles, commonBorder, commonSizes, center, centerX, centerY, commonColor, commonJcAlineFlexStyle, commonGapStyles, commonFlexStyle, commonShadowStyles, commonAlignSelf, commonBorderColor, commonTextColor, commonFlexStyles, };
//# sourceMappingURL=style.component.d.ts.map