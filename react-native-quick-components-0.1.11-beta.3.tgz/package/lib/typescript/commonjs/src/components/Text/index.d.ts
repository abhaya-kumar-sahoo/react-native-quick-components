import type { CustomTextProps } from '../../types/types';
import React from 'react';
export declare const AppText: React.FC<CustomTextProps>;
//# sourceMappingURL=index.d.ts.map