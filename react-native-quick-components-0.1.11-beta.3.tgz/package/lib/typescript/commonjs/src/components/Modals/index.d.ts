export default function AppModal(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=index.d.ts.map