import type { DividerProps } from '../../types/types';
import React from 'react';
export declare const Divider: React.FC<DividerProps>;
//# sourceMappingURL=index.d.ts.map