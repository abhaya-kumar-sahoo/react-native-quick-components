import type { RowViewProps } from '../../types/types';
import React from 'react';
export declare const RowView: React.FC<RowViewProps>;
export declare const ColView: React.FC<RowViewProps>;
//# sourceMappingURL=row.col.index.d.ts.map