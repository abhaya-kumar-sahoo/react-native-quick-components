import type { HeightWidthTypes } from '../types/h_w_types';
declare const VertSpace: ({ size }: {
    size?: HeightWidthTypes;
}) => import("react/jsx-runtime").JSX.Element;
declare const HorizSpace: ({ size }: {
    size?: HeightWidthTypes;
}) => import("react/jsx-runtime").JSX.Element;
export { VertSpace, HorizSpace };
//# sourceMappingURL=index.d.ts.map