export declare const isIOS: boolean;
export declare const isAndroid: boolean;
export declare const isWeb: boolean;
export declare const isMacOs: boolean;
export declare const isWindows: boolean;
export declare const isTv: boolean;
export declare const SCREEN_H: number, SCREEN_W: number;
/**
 * Determines if the device is in landscape orientation.
 * @type {boolean}
 */
export declare const isLandscape: boolean;
/**
 * Determines if the device is in portrait orientation.
 * @type {boolean}
 */
export declare const isPortrait: boolean;
//# sourceMappingURL=platform.d.ts.map